# Task 33 — Content Security Policy (CSP)

## Objective
Implement CSP in an Express application that:
- Blocks inline JavaScript.
- Blocks third-party JavaScript sources.
- Allows trusted local JavaScript.
- Demonstrates CSP violations in the browser console.
- Keeps the application functional.

## Run

```bash
cd csp-security-task
npm install
npm start
```

Open:

http://localhost:3000

## Working-app proof

Click **Test Working JavaScript**. The page should display:

`CSP-protected JavaScript is working!`

## CSP header proof

Open Chrome DevTools:
1. Network
2. Reload the page
3. Select the document request
4. Open Headers
5. Under Response Headers, find `Content-Security-Policy`

The important directive is:

`script-src 'self'`

## Test 1 — Block inline JavaScript

Temporarily add this before `</body>` in `public/index.html`:

```html
<script>
  alert("This inline script should be blocked!");
</script>
```

Reload the page and open DevTools → Console.

You should see a CSP error stating that execution of the inline script was refused because it violates:

`script-src 'self'`

Remove the test script afterward.

## Test 2 — Block third-party JavaScript

Temporarily add:

```html
<script src="https://example.com/test.js"></script>
```

Reload and check DevTools → Console.

The browser should report that the script was refused because it violates:

`script-src 'self'`

Remove the test script afterward.

## What attacks does CSP reduce?

CSP primarily reduces the risk and impact of Cross-Site Scripting (XSS), including stored, reflected, and DOM-based XSS. It can also restrict unauthorized external resources and, with `frame-ancestors`, help mitigate clickjacking.

CSP is defense-in-depth and does not replace input validation, output encoding, authentication, or authorization.

## What is a nonce?

A nonce is a cryptographically random, unpredictable value generated for a response and placed both in the CSP and on a trusted inline script:

```http
Content-Security-Policy: script-src 'self' 'nonce-randomValue'
```

```html
<script nonce="randomValue">
  // trusted inline code
</script>
```

Only an inline script carrying the correct nonce is allowed to execute.

## Evidence to submit

Take these screenshots:
1. CSP header in Network → Response Headers.
2. Blocked inline script error in Console.
3. Blocked third-party script error in Console.
4. Working application after removing the test violations.
