document.addEventListener("DOMContentLoaded", () => {
  const button = document.getElementById("messageButton");
  const output = document.getElementById("output");

  button.addEventListener("click", () => {
    output.textContent = "CSP-protected JavaScript is working!";
  });
});
